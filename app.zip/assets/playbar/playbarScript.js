cp.playbarAssetArr = 
[
	'AudioOff',
	'AudioOn',
	'BackGround',
	'Backward',
	'Color',
	'ColorSmall',
	'CC',
	'Exit',
	'FastForward',
	'FastForward1',
	'FastForward2',
	'Forward',
	'Glow',
	'GlowSmall',
	'Height',
	'InnerStroke',
	'InnerStrokeSmall',
	'Play',
	'Pause',
	'Progress',
	'Rewind',
	'Shade',
	'ShadeSmall',
	'Stroke',
	'StrokeSmall',
	'Thumb',
	'ThumbBase',
	'TOC'
];
cp.playbarTooltips = 
{
	AudioOff : "Audio activ� ",
	AudioOn : "Audio d�sactiv� ",
	Backward : "Retour ",
	CC : "Sous-titrage ",
	Exit : "Quitter ",
	FastForward : "Vitesse d'avance rapide x2 ",
	FastForward1 : "Vitesse d'avance rapide x4 ",
	FastForward2 : "Vitesse normale ",
	Forward : "Avancer ",
	Play : "Lire ",
	Pause : "Pause ",
	Rewind : "Rembobiner ",
	TOC : "Table des mati�res ",
	Info : "Informations ",
	Print : "Imprimer "
};
cp.handleSpecialForPlaybar = function(playbarConstruct)
{
}